package com.capgemini.truckbooking.service;

import java.util.List;

import com.capgemini.truckbooking.TTBOException.BookingException;
import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.truckbooking.dao.ITruckDao;
import com.capgemini.truckbooking.dao.TruckDao;

public class TruckService implements ITruckService {

	ITruckDao truckDao = new TruckDao();

	@Override
	public List<TruckBean> retriveTruckDetails() throws BookingException {

		return truckDao.retriveTruckDetails();
	}

	@Override
	public int bookTrucks(BookingBean bookingBean) throws BookingException {
		truckDao = new TruckDao();
		return truckDao.bookTrucks(bookingBean);
	}

}
