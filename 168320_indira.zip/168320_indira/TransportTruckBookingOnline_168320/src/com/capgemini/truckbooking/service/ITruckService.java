package com.capgemini.truckbooking.service;

import java.util.List;

import com.capgemini.truckbooking.TTBOException.BookingException;
import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.bean.TruckBean;

public interface ITruckService {

	List<TruckBean> retriveTruckDetails() throws BookingException;

	int bookTrucks(BookingBean bookingBean) throws BookingException;

}
