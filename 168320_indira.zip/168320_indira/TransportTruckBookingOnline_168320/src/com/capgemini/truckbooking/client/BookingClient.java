package com.capgemini.truckbooking.client;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Pattern;

import com.capgemini.truckbooking.TTBOException.BookingException;
import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.truckbooking.service.ITruckService;
import com.capgemini.truckbooking.service.TruckService;

public class BookingClient {
	public static void main(String[] args) {

		Scanner scanner = null;
		boolean flag = false, custIDFlag = false,truckIDFlag=false,truckIDFlagInput=false,dateFlag=false,truckAvailability=false,truckAvailabilityInput=false,mobileFlag=false;
		int choice = 0;
		List<TruckBean> list = new ArrayList<>();
		String custID;
		int truckID,noOfTrucks;
		int insertResult=0;
		long custMobile;
		String custIDRegEX,custMobileRegEx,transportDate;
		LocalDate dateOfTransport;
		DateTimeFormatter dateTimeFormatter;
		BookingBean bookingBean;
		ITruckService truckService;

		do {

			System.out.println("*****TRANSPORT TRUCK BOOKING OBLINE*****");
			System.out.println("1. Book Trucks ");
			System.out.println("2. Exit ");
			scanner = new Scanner(System.in);
			System.out.println("enter your choice");
			try {
				choice = scanner.nextInt();
				flag = true;
				switch (choice) {
				case 1:
					System.out.println("Book Trucks");
					System.out.println("enter customer ID: ");
					scanner.nextLine();
					do {
						custID = scanner.nextLine();
						custIDFlag = true;
						custIDRegEX = "^[A-Z]{1}[0-9]{6}$";
						if (Pattern.matches(custIDRegEX, custID)) {
						 truckService = new TruckService();
							try {
								list = truckService.retriveTruckDetails();
								if (list.size() > 0) {
									for (TruckBean truckBean : list) {
										System.out.println("truckID = " + truckBean.getTruckID() + " truck type = "
												+ truckBean.getTruckType() + " origin = " + truckBean.getOrigin()
												+ " destination = " + truckBean.getDestination() + " charges = "
												+ truckBean.getCharges() + " Available no of trucks = "
												+ truckBean.getAvailableNos());
										
										}
									
									do{
										System.out.println("enter truckID : ");
									truckID=scanner.nextInt();
									truckIDFlagInput=true;
									for (TruckBean truckBean : list) {
										if(truckID==truckBean.getTruckID()) {
											truckIDFlag=true;
											
										}
									}
									if(truckIDFlag==false) {
										truckIDFlagInput=false;
										System.out.println("no truck found");
										System.out.println("enter truckID again ");
									}
									else {
										
										do {
											
										System.out.println("enter number of trucks: ");
										truckAvailabilityInput=true;
										noOfTrucks=scanner.nextInt();
										for (TruckBean truckBean : list) {
											if(noOfTrucks>0 && noOfTrucks<=truckBean.getAvailableNos()) {
												truckAvailability=true;
											}
										}
										if(truckAvailability==false) {
											truckAvailabilityInput=false;
											System.out.println(noOfTrucks+" trucks are not available");
											System.out.println("enter number of trucks again");
										}
										
										else {
											do {
												mobileFlag=true;
											System.out.println("enter customer mobile number: ");
											custMobile=scanner.nextLong();
											custMobileRegEx="^[6|7|8|9]{1}[0-9]{9}$";
											if(Pattern.matches(custMobileRegEx, String.valueOf(custMobile))) {
												scanner.nextLine();
												do {
												try {
												System.out.println("enter date in year-month-day format");
												dateFlag=true;
												transportDate=scanner.nextLine();
												dateOfTransport = LocalDate.parse(transportDate);
												dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
												dateOfTransport.format(dateTimeFormatter);
											bookingBean=new BookingBean();
											bookingBean.setCustId(custID);
											bookingBean.setCustMobile(custMobile);
											bookingBean.setTruckId(truckID);
											bookingBean.setNoOfTrucks(noOfTrucks);
											bookingBean.setDateOfTransport(dateOfTransport);
											
											truckService = new TruckService();
											insertResult=truckService.bookTrucks(bookingBean);
												
											System.out.println("your booking Id is "+insertResult);
												
												}catch (DateTimeParseException e) {
													dateFlag=false;
													System.err.println("enter date properly");
													System.err.println("enter date in year-month-day format again");
												}
												}while(!dateFlag);
												
											}
											else {
												mobileFlag=false;
												System.out.println("invalid mobile number");
												System.out.println("enter mobile number again");
											}
										}while(!mobileFlag);
										
										}
									}while(!truckAvailabilityInput);
										
									}
										
									}while(!truckIDFlagInput);
									
								}
								else {
									System.out.println("no trucks in database");
								}
								
								
								
								
								

							} catch (BookingException e) {
								e.printStackTrace();
							}
						} else {
							custIDFlag = false;
							System.err.println("invalid customer ID format");
							System.err.println("enter customer ID again");
						}

					} while (!custIDFlag);
					break;

				case 2:
					System.out.println("exited");
					System.exit(0);
					break;
				default:
					flag = false;
					System.err.println("enter choice from 1 and 2 options");
					System.err.println("enter input again");

				}
			} catch (InputMismatchException e) {
				System.err.println("enter only digits");
				System.err.println("enter input again");
			}
		} while (!flag);
		scanner.close();

	}

}
