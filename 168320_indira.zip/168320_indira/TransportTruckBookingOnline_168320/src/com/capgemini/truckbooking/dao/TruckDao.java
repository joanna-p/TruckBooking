package com.capgemini.truckbooking.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.capgemini.truckbooking.TTBOException.BookingException;
import com.capgemini.truckbooking.Utility.TTBOUtility;
import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.bean.TruckBean;

public class TruckDao implements ITruckDao {

	Connection connection = null;
	Statement statement = null;
	List<TruckBean> list;
	static Logger logger=Logger.getLogger(TruckDao.class);
	ResultSet resultSet = null;
	TruckBean truckBean;
	PreparedStatement preparedStatement = null;
	PreparedStatement preparedStatement1 = null;
	PreparedStatement preparedStatement2 = null;
	@Override
	public List<TruckBean> retriveTruckDetails() throws BookingException {

		connection = TTBOUtility.getConnection();
		try {
			statement = connection.createStatement();
			list = new ArrayList<TruckBean>();
			resultSet = statement.executeQuery(QueryMapper.display);
			while (resultSet.next()) {
				int truckID = resultSet.getInt(1);
				String truckType = resultSet.getString(2);
				String origin = resultSet.getString(3);
				String destination = resultSet.getString(4);
				float charges = resultSet.getFloat(5);
				int availableNos = resultSet.getInt(6);

				TruckBean truckBean = new TruckBean();
				truckBean.setTruckID(truckID);
				truckBean.setTruckType(truckType);
				truckBean.setOrigin(origin);
				truckBean.setDestination(destination);
				truckBean.setCharges(charges);
				truckBean.setAvailableNos(availableNos);

				list.add(truckBean);

			}

		} catch (SQLException e) {

			e.printStackTrace();
		}

		return list;
	}

	@Override
	public int bookTrucks(BookingBean bookingBean) throws BookingException {
		int result = 0,updateResult=0,bookingId = 0;
		connection = TTBOUtility.getConnection();
		ResultSet resultset2=null;
		LocalDate date = bookingBean.getDateOfTransport();
		Date sqlDate = Date.valueOf(date);
		try {
			preparedStatement = connection.prepareStatement(QueryMapper.insert);
			preparedStatement.setString(1, bookingBean.getCustId());
			preparedStatement.setLong(2, bookingBean.getCustMobile());
			preparedStatement.setInt(3, bookingBean.getTruckId());
			preparedStatement.setInt(4, bookingBean.getNoOfTrucks());
			preparedStatement.setDate(5, sqlDate);
			result = preparedStatement.executeUpdate();
			
			if(result>0) {
				preparedStatement1 = connection.prepareStatement(QueryMapper.update);
				preparedStatement1.setInt(1, bookingBean.getNoOfTrucks());
				preparedStatement1.setInt(2, bookingBean.getTruckId());
				updateResult=preparedStatement1.executeUpdate();
				if(updateResult>0)
				{
					preparedStatement2=connection.prepareStatement(QueryMapper.bookingId);
					resultset2=preparedStatement2.executeQuery();
					resultset2.next();
					bookingId=resultset2.getInt(1);
					
				}else {
					System.out.println("not updated in truck details");
				}
				
				
				
			}else {
				System.out.println("not inserted");
			}
			}catch (SQLException e) {
			e.printStackTrace();
		}
		return bookingId;
	}

}
