package com.capgemini.truckbooking.dao;

public interface QueryMapper {

	public static final String display = "SELECT * FROM TruckDetails";
	public static final String insert = "INSERT INTO BookingDetails VALUES(booking_id_seq.NEXTVAL,?,?,?,?,?)";
	public static final String update = "UPDATE TRUCKDETAILS set availableNos=availableNos-? where truckID=?";
	public static final String bookingId = "select booking_id_seq.CURRVAL FROM DUAL";

}
