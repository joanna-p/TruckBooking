package com.capgemini.truckbooking.dao;

import java.util.List;

import com.capgemini.truckbooking.TTBOException.BookingException;
import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.bean.TruckBean;

public interface ITruckDao {

	List<TruckBean> retriveTruckDetails() throws BookingException;

	int bookTrucks(BookingBean bookingBean) throws BookingException;

}
