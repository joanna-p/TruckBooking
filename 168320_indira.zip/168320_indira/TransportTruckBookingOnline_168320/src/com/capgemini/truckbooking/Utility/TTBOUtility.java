package com.capgemini.truckbooking.Utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.capgemini.truckbooking.TTBOException.BookingException;

public class TTBOUtility {
	private static Connection connection = null;

	public static Connection getConnection() throws BookingException {

		File file = null;
		FileInputStream fileInputStream = null;
		file = new File("resources/jdbc.properties");
		try {
			fileInputStream = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			throw new BookingException(e.getMessage());
		}

		Properties properties = new Properties();

		try {
			properties.load(fileInputStream);

			String driver = properties.getProperty("db.driver");
			String url = properties.getProperty("db.url");
			String username = properties.getProperty("db.usename");
			String password = properties.getProperty("db.password");

			Class.forName(driver);
			connection = DriverManager.getConnection(url, username, password);

		} catch (IOException e) {
			throw new BookingException(e.getMessage());
		} catch (ClassNotFoundException e) {
			throw new BookingException(e.getMessage());
		} catch (SQLException e) {
			throw new BookingException(e.getMessage());
		}
		return connection;
	}
}
